# Casagrand IT Operations Portal

React + Vite dashboard for the IT team — login, module grid, and full Attendance
upload/validation flow.

## Run locally
```
npm install
npm run dev
```
Open the printed localhost URL. Sign in with `Casagrand` / `Casa@2026` (fixed
demo credentials checked in `src/pages/Login.jsx` — since this ships in the
browser bundle, anyone can read the JS and see them, so swap this for real
server-side auth before this goes in front of anyone outside the IT team).

## Build for hosting (Netlify/Vercel/etc.)
```
npm run build
```
Deploy the generated `dist/` folder.

## What's inside
- **Login** — Casagrand-branded sign-in screen.
- **Dashboard home** — bento-style grid (varied card sizes, circular gauges for Attendance/Assets/Tickets) instead of a flat card grid, plus a search bar that filters modules and looks up tickets/employees/assets/applications by name.
- **IT Assets** — laptop/desktop stock across In Use / In Stock / In Repair / In Store,
  manual add + Excel/CSV bulk upload.
- **Tickets** — Open / Hold / Closed board.
- **Applications** — application/ownership list, bulk upload.
- **Service & Firewall** — server + firewall status tables.
- **Employee Details** — master employee list, seat/license allocation, bulk upload.
- **Attendance** — today's Present/Absent grid front-and-center, plus file upload:
  - `.xlsx` / `.csv` files are parsed for real and validated purely from the file
    itself (no dependency on any internal demo data) — each row needs an ID, a
    Name, a recognised Present/Absent status, and no duplicate ID in the file.
    Rows that pass show green **Approved**; anything missing/invalid shows red
    **Mismatch** with the reason.
  - Other file types (PDF, images, etc.) are accepted and listed, but flagged
    **Manual review** since they can't be parsed client-side without OCR.
- **Theme toggle** (light/dark) and a date picker in the top bar.

## Data & multi-user note
Everything currently lives in the browser's `localStorage` (per-computer only) —
there is no server yet, so two people on two different computers won't see each
other's changes. For true multi-user access across different computers (several
employees updating it, and you seeing it live as the main user) a real backend +
database is required — wire the `setX` calls in `src/pages/Dashboard.jsx` to
that API once it's ready.
