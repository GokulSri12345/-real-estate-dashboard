export const seedEmployees = [
  { id: 'CG001', name: 'Arun Kumar', dept: 'Sales', status: 'Present' },
  { id: 'CG002', name: 'Divya Sree', dept: 'HR', status: 'Present' },
  { id: 'CG003', name: 'Karthik Raja', dept: 'Finance', status: 'Absent' },
  { id: 'CG004', name: 'Meena Priya', dept: 'IT', status: 'Present' },
  { id: 'CG005', name: 'Suresh Babu', dept: 'Projects', status: 'Present' },
  { id: 'CG006', name: 'Lakshmi Narayanan', dept: 'Sales', status: 'Absent' },
  { id: 'CG007', name: 'Vignesh S', dept: 'Legal', status: 'Present' },
  { id: 'CG008', name: 'Priya Dharshini', dept: 'HR', status: 'Present' },
  { id: 'CG009', name: 'Bala Murugan', dept: 'Projects', status: 'Absent' },
  { id: 'CG010', name: 'Anitha Ravi', dept: 'Finance', status: 'Present' },
];

export const seedAssets = [
  { id: 'AST-101', type: 'Laptop', model: 'Lenovo ThinkPad E14', assignedTo: 'Arun Kumar', status: 'In Use' },
  { id: 'AST-102', type: 'Laptop', model: 'Dell Latitude 5420', assignedTo: '-', status: 'In Stock' },
  { id: 'AST-103', type: 'Laptop', model: 'HP ProBook 440', assignedTo: '-', status: 'In Repair' },
  { id: 'AST-104', type: 'Desktop', model: 'Dell OptiPlex 3080', assignedTo: 'Finance Desk 2', status: 'In Use' },
  { id: 'AST-105', type: 'Laptop', model: 'Lenovo ThinkPad E14', assignedTo: '-', status: 'In Store' },
  { id: 'AST-106', type: 'Desktop', model: 'HP EliteDesk 800', assignedTo: '-', status: 'In Stock' },
];

export const seedTickets = [
  { id: 'TCK-3301', subject: 'VPN not connecting', raisedBy: 'Karthik Raja', status: 'Open' },
  { id: 'TCK-3302', subject: 'New laptop request', raisedBy: 'Meena Priya', status: 'Hold' },
  { id: 'TCK-3303', subject: 'Printer offline - 2nd floor', raisedBy: 'Suresh Babu', status: 'Closed' },
  { id: 'TCK-3304', subject: 'Email DL access', raisedBy: 'Anitha Ravi', status: 'Open' },
  { id: 'TCK-3305', subject: 'SAP login locked', raisedBy: 'Vignesh S', status: 'Closed' },
];

export const seedApplications = [
  { name: 'SAP SuccessFactors (MyZone)', owner: 'HR Ops', status: 'Active' },
  { name: 'IBM RPA Studio', owner: 'IT Automation', status: 'Active' },
  { name: 'PeopleStrong', owner: 'HR Ops', status: 'Active' },
  { name: 'Tally ERP', owner: 'Finance', status: 'Active' },
  { name: 'Legacy Timesheet Tool', owner: 'IT', status: 'Deprecated' },
];

export const seedServices = [
  { name: 'File Server - Chennai HO', ip: '10.20.4.10', status: 'Running' },
  { name: 'Mail Server (Exchange)', ip: '10.20.4.22', status: 'Running' },
  { name: 'Backup Service', ip: '10.20.4.40', status: 'Warning' },
];

export const seedFirewalls = [
  { name: 'Perimeter FW - HO', vendor: 'Fortinet', status: 'Active', lastAudit: '2026-07-15' },
  { name: 'Branch FW - OMR', vendor: 'Sophos', status: 'Active', lastAudit: '2026-06-02' },
  { name: 'DC Firewall', vendor: 'Fortinet', status: 'Needs Review', lastAudit: '2026-03-11' },
];

export const seedInfra = { allocatedSeats: 30, totalSeats: 35, activeUsers: 26, totalLicenses: 30 };
