import { useState } from 'react';
import { Lock, User } from 'lucide-react';
import logo from '../assets/casagrand-logo.png';

// Demo-only fixed credentials — visible in the shipped JS bundle, so this is
// fine for an internal preview but should be swapped for real server-side
// auth before this goes in front of anyone outside the IT team.
const VALID_USERNAME = 'Casagrand';
const VALID_PASSWORD = 'Casa@2026';

export default function Login({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setError('Enter both username and password.');
      return;
    }
    if (username.trim() !== VALID_USERNAME || password !== VALID_PASSWORD) {
      setError('Invalid username or password.');
      return;
    }
    setError('');
    onLogin(username.trim());
  }

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background:
          'radial-gradient(1100px 500px at 15% -10%, rgba(47,95,219,.3), transparent), var(--navy-900)',
        padding: 20,
      }}
    >
      <div
        style={{
          width: '100%',
          maxWidth: 400,
          background: 'var(--surface)',
          borderRadius: 'var(--radius-lg)',
          boxShadow: '0 24px 60px rgba(0,0,0,.35)',
          padding: '38px 34px 30px',
        }}
      >
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, marginBottom: 26 }}>
          <img src={logo} alt="Casagrand" style={{ height: 52, objectFit: 'contain', marginBottom: 6 }} />
          <h1 style={{ fontSize: 20, fontWeight: 800 }}>IT Operations Portal</h1>
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <label style={fieldLabel}>Username</label>
          <div style={inputWrap}>
            <User size={16} color="var(--muted)" />
            <input
              autoFocus
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
              style={inputStyle}
            />
          </div>

          <label style={fieldLabel}>Password</label>
          <div style={inputWrap}>
            <Lock size={16} color="var(--muted)" />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              style={inputStyle}
            />
          </div>

          {error && <p style={{ color: 'var(--red-600)', fontSize: 12.5, margin: 0 }}>{error}</p>}

          <button
            type="submit"
            style={{
              marginTop: 8,
              background: 'var(--blue-600)',
              color: '#fff',
              border: 'none',
              borderRadius: 10,
              padding: '12px 0',
              fontWeight: 700,
              fontSize: 14.5,
              cursor: 'pointer',
            }}
          >
            Sign in
          </button>
        </form>
      </div>
    </div>
  );
}

const fieldLabel = { fontSize: 12.5, fontWeight: 600, color: 'var(--muted)', marginBottom: -6 };
const inputWrap = {
  display: 'flex',
  alignItems: 'center',
  gap: 10,
  border: '1px solid var(--border)',
  borderRadius: 10,
  padding: '11px 12px',
  background: 'var(--bg)',
};
const inputStyle = {
  border: 'none',
  outline: 'none',
  background: 'transparent',
  width: '100%',
  fontSize: 14,
  color: 'var(--ink)',
};
