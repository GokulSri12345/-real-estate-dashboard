import { useMemo, useState } from 'react';
import { Laptop, Ticket, AppWindow, Server, ShieldCheck, Users, CalendarCheck2, ArrowUpRight } from 'lucide-react';
import Topbar from '../components/Topbar';
import SearchBar from '../components/SearchBar';
import { CountChip } from '../components/StatusBadge';
import AssetsSection from '../sections/AssetsSection';
import TicketsSection from '../sections/TicketsSection';
import ApplicationsSection from '../sections/ApplicationsSection';
import ServiceSection from '../sections/ServiceSection';
import FirewallSection from '../sections/FirewallSection';
import EmployeeSection from '../sections/EmployeeSection';
import AttendanceSection from '../sections/AttendanceSection';
import { loadData, saveData } from '../utils/storage';
import {
  seedAssets, seedTickets, seedApplications, seedServices, seedFirewalls, seedEmployees, seedInfra,
} from '../data/seed';

const MODULE_META = {
  attendance: { title: 'Attendance', caption: 'Live check-in tracking', icon: CalendarCheck2, accent: 'var(--green-600)', accentSoft: 'var(--green-50)' },
  assets: { title: 'IT Assets', caption: 'Fleet inventory & lifecycle', icon: Laptop, accent: 'var(--navy-800)', accentSoft: 'rgba(31,59,120,0.08)' },
  tickets: { title: 'Tickets', caption: 'Support request queue', icon: Ticket, accent: 'var(--blue-600)', accentSoft: 'rgba(47,95,219,0.08)' },
  applications: { title: 'Applications', caption: 'Software portfolio', icon: AppWindow, accent: 'var(--amber-600)', accentSoft: 'var(--amber-50)' },
  services: { title: 'Service Details', caption: 'Infrastructure health', icon: Server, accent: 'var(--navy-700)', accentSoft: 'rgba(44,79,158,0.08)' },
  firewalls: { title: 'Firewall Details', caption: 'Perimeter security', icon: ShieldCheck, accent: 'var(--navy-700)', accentSoft: 'rgba(44,79,158,0.08)' },
  employees: { title: 'Employee Details', caption: 'Workforce roster', icon: Users, accent: 'var(--blue-500)', accentSoft: 'rgba(92,130,236,0.08)' },
};

const ASSET_STATUSES = ['In Use', 'In Stock', 'In Repair', 'In Store'];

export default function Dashboard({ user, theme, onToggleTheme, onLogout }) {
  const [active, setActive] = useState(null);
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [query, setQuery] = useState('');

  const [assets, setAssetsState] = useState(() => loadData('assets', seedAssets));
  const [tickets, setTicketsState] = useState(() => loadData('tickets', seedTickets));
  const [applications, setApplicationsState] = useState(() => loadData('applications', seedApplications));
  const [employees, setEmployeesState] = useState(() => loadData('employees', seedEmployees));

  function setAssets(v) { setAssetsState(v); saveData('assets', v); }
  function setTickets(v) { setTicketsState(v); saveData('tickets', v); }
  function setApplications(v) { setApplicationsState(v); saveData('applications', v); }
  function setEmployees(v) { setEmployeesState(v); saveData('employees', v); }

  const activeMeta = active && MODULE_META[active];

  // ---- Breakdown counts per module ----
  const present = employees.filter((e) => e.status === 'Present').length;
  const absent = employees.length - present;
  const pct = (n, d) => (d > 0 ? Math.round((n / d) * 100) : 0);

  const inUseCount = assets.filter((a) => a.status === 'In Use').length;
  const assetCounts = ASSET_STATUSES.map((s) => ({ label: s, value: assets.filter((a) => a.status === s).length })).filter((c) => c.value > 0);

  const openTickets = tickets.filter((t) => t.status === 'Open').length;
  const holdTickets = tickets.filter((t) => t.status === 'Hold').length;
  const closedTickets = tickets.filter((t) => t.status === 'Closed').length;

  const activeApps = applications.filter((a) => a.status === 'Active').length;
  const deprecatedApps = applications.filter((a) => a.status === 'Deprecated').length;

  const runningServices = seedServices.filter((s) => s.status === 'Running').length;
  const warningServices = seedServices.filter((s) => s.status !== 'Running').length;

  const activeFirewalls = seedFirewalls.filter((f) => f.status === 'Active').length;
  const reviewFirewalls = seedFirewalls.filter((f) => f.status !== 'Active').length;

  const deptCount = new Set(employees.map((e) => e.dept)).size;

  const searchResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    const hits = [];
    tickets.forEach((t) => { if (t.subject.toLowerCase().includes(q) || t.id.toLowerCase().includes(q)) hits.push({ key: 'tickets', label: `${t.id} — ${t.subject}`, type: 'Ticket' }); });
    employees.forEach((e) => { if (e.name.toLowerCase().includes(q) || e.id.toLowerCase().includes(q)) hits.push({ key: 'employees', label: `${e.name} (${e.id})`, type: 'Employee' }); });
    assets.forEach((a) => { if (a.model.toLowerCase().includes(q) || a.id.toLowerCase().includes(q)) hits.push({ key: 'assets', label: `${a.id} — ${a.model}`, type: 'Asset' }); });
    applications.forEach((a) => { if (a.name.toLowerCase().includes(q)) hits.push({ key: 'applications', label: a.name, type: 'Application' }); });
    Object.entries(MODULE_META).forEach(([key, m]) => { if (m.title.toLowerCase().includes(q)) hits.push({ key, label: m.title, type: 'Module' }); });
    return hits.slice(0, 8);
  }, [query, tickets, employees, assets, applications]);

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Topbar
        theme={theme}
        onToggleTheme={onToggleTheme}
        date={date}
        onDateChange={setDate}
        user={user}
        onLogout={onLogout}
        onBack={() => setActive(null)}
        sectionTitle={activeMeta?.title}
      />

      {!active && (
        <div style={{ padding: '26px 28px 60px', maxWidth: 1180, margin: '0 auto' }}>
          <div style={{ marginBottom: 18 }}>
            <h2 style={{ fontSize: 22, fontWeight: 800 }}>Dashboard</h2>
            <p style={{ margin: '4px 0 0', color: 'var(--muted)', fontSize: 13.5 }}>
              Live status across every IT module, in one view.
            </p>
          </div>

          <SearchBar value={query} onChange={setQuery} resultCount={query ? searchResults.length : undefined} />

          {query && (
            <div style={{ border: '1px solid var(--border)', background: 'var(--surface)', borderRadius: 12, boxShadow: 'var(--shadow-card)', marginBottom: 22, overflow: 'hidden' }}>
              {searchResults.length === 0 && <div style={{ padding: 16, fontSize: 13, color: 'var(--muted)' }}>No matches for "{query}".</div>}
              {searchResults.map((r, i) => (
                <button
                  key={i}
                  onClick={() => { setActive(r.key); setQuery(''); }}
                  style={{
                    display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'space-between',
                    padding: '11px 16px', border: 'none', background: 'transparent', cursor: 'pointer',
                    borderTop: i === 0 ? 'none' : '1px solid var(--border)', fontSize: 13.5, color: 'var(--ink)', textAlign: 'left',
                  }}
                >
                  <span>{r.label}</span>
                  <span style={{ fontSize: 11.5, color: 'var(--muted)' }}>{r.type}</span>
                </button>
              ))}
            </div>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(255px, 1fr))', gap: 18 }}>
            <Card meta={MODULE_META.attendance} onClick={() => setActive('attendance')} hero={`${pct(present, employees.length)}%`} heroLabel="Present today">
              <ChipRow chips={[{ label: 'Present', value: present }, { label: 'Absent', value: absent }]} />
            </Card>

            <Card meta={MODULE_META.assets} onClick={() => setActive('assets')} hero={`${pct(inUseCount, assets.length)}%`} heroLabel="Utilization">
              <ChipRow chips={assetCounts} />
            </Card>

            <Card meta={MODULE_META.tickets} onClick={() => setActive('tickets')} hero={`${pct(closedTickets, tickets.length)}%`} heroLabel="Resolved">
              <ChipRow chips={[{ label: 'Open', value: openTickets }, { label: 'Hold', value: holdTickets }, { label: 'Closed', value: closedTickets }]} />
            </Card>

            <Card meta={MODULE_META.applications} onClick={() => setActive('applications')} hero={`${pct(activeApps, applications.length)}%`} heroLabel="Active">
              <ChipRow chips={[{ label: 'Active', value: activeApps }, { label: 'Deprecated', value: deprecatedApps }]} />
            </Card>

            <Card meta={MODULE_META.services} onClick={() => setActive('services')} hero={`${pct(runningServices, seedServices.length)}%`} heroLabel="Uptime">
              <ChipRow chips={[{ label: 'Running', value: runningServices }, { label: 'Warning', value: warningServices }]} />
            </Card>

            <Card meta={MODULE_META.firewalls} onClick={() => setActive('firewalls')} hero={`${pct(activeFirewalls, seedFirewalls.length)}%`} heroLabel="Secure">
              <ChipRow chips={[{ label: 'Active', value: activeFirewalls }, { label: 'Needs Review', value: reviewFirewalls }]} />
            </Card>

            <Card meta={MODULE_META.employees} onClick={() => setActive('employees')} hero={`${employees.length}`} heroLabel="Team members">
              <ChipRow chips={[{ label: 'Total', value: employees.length, tone: 'blue' }, { label: 'Departments', value: deptCount, tone: 'muted' }]} />
            </Card>
          </div>
        </div>
      )}

      {active === 'assets' && <AssetsSection assets={assets} setAssets={setAssets} />}
      {active === 'tickets' && <TicketsSection tickets={tickets} setTickets={setTickets} />}
      {active === 'applications' && <ApplicationsSection applications={applications} setApplications={setApplications} />}
      {active === 'services' && <ServiceSection services={seedServices} />}
      {active === 'firewalls' && <FirewallSection firewalls={seedFirewalls} />}
      {active === 'employees' && <EmployeeSection employees={employees} setEmployees={setEmployees} infra={seedInfra} />}
      {active === 'attendance' && <AttendanceSection employees={employees} date={date} />}
    </div>
  );
}

function Card({ meta, onClick, hero, heroLabel, children }) {
  const Icon = meta.icon;
  const [hovered, setHovered] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        position: 'relative',
        overflow: 'hidden',
        textAlign: 'left',
        border: `1px solid ${hovered ? `${meta.accent}55` : 'var(--border)'}`,
        background: 'var(--surface)',
        borderRadius: 'var(--radius-lg)',
        padding: '20px 20px 18px',
        boxShadow: hovered ? 'var(--shadow-pop)' : 'var(--shadow-card)',
        cursor: 'pointer',
        display: 'flex',
        flexDirection: 'column',
        gap: 14,
        minHeight: 196,
        transition: 'box-shadow .2s ease, border-color .2s ease, transform .2s ease',
        transform: hovered ? 'translateY(-3px)' : 'translateY(0)',
      }}
    >
      {/* faint watermark icon for depth */}
      <Icon
        size={104}
        style={{
          position: 'absolute',
          top: -22,
          right: -22,
          color: meta.accent,
          opacity: 0.06,
          transform: hovered ? 'scale(1.08) rotate(6deg)' : 'scale(1) rotate(0deg)',
          transition: 'transform .25s ease',
        }}
      />

      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', position: 'relative' }}>
        <div>
          <h3 style={{ fontSize: 15.5, fontWeight: 800, letterSpacing: -0.1 }}>{meta.title}</h3>
          <p style={{ margin: '3px 0 0', fontSize: 11.5, color: 'var(--muted)', fontWeight: 600 }}>{meta.caption}</p>
        </div>
        <div
          style={{
            width: 38,
            height: 38,
            borderRadius: 11,
            background: `linear-gradient(145deg, ${meta.accent}, ${meta.accent}CC)`,
            color: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
            boxShadow: `0 6px 14px ${meta.accent}4D`,
          }}
        >
          <Icon size={17} />
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, position: 'relative' }}>
        <span style={{ fontFamily: "'Sora',sans-serif", fontWeight: 800, fontSize: 32, lineHeight: 1, color: meta.accent }}>{hero}</span>
        <span style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 600 }}>{heroLabel}</span>
      </div>

      <div style={{ height: 1, background: 'var(--border)', margin: '0 -2px' }} />

      <div style={{ marginTop: 'auto', position: 'relative' }}>{children}</div>

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 4,
          fontSize: 11.5,
          fontWeight: 700,
          color: hovered ? meta.accent : 'var(--muted)',
          transition: 'color .2s ease',
        }}
      >
        View details <ArrowUpRight size={13} style={{ transform: hovered ? 'translate(1px,-1px)' : 'none', transition: 'transform .2s ease' }} />
      </div>
    </button>
  );
}

function ChipRow({ chips }) {
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
      {chips.map((c) => (
        <CountChip key={c.label} label={c.label} value={c.value} tone={c.tone} />
      ))}
    </div>
  );
}
