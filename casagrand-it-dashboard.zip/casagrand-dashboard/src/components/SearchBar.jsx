import { Search, X } from 'lucide-react';

export default function SearchBar({ value, onChange, resultCount }) {
  return (
    <div style={{ position: 'relative', marginBottom: 18 }}>
      <Search size={16} color="var(--muted)" style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)' }} />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Search modules, tickets, employees, assets..."
        style={{
          width: '100%',
          border: '1px solid var(--border)',
          background: 'var(--surface)',
          borderRadius: 12,
          padding: '12px 40px',
          fontSize: 14,
          color: 'var(--ink)',
          boxShadow: 'var(--shadow-card)',
        }}
      />
      {value && (
        <button
          onClick={() => onChange('')}
          style={{
            position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
            border: 'none', background: 'transparent', cursor: 'pointer', color: 'var(--muted)',
            display: 'flex', alignItems: 'center', gap: 6, fontSize: 12,
          }}
        >
          {resultCount !== undefined && <span>{resultCount} result{resultCount === 1 ? '' : 's'}</span>}
          <X size={15} />
        </button>
      )}
    </div>
  );
}
