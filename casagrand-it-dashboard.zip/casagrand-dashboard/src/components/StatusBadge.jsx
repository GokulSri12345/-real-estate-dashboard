const TONES = {
  green: { bg: 'var(--green-50)', fg: 'var(--green-600)' },
  red: { bg: 'var(--red-50)', fg: 'var(--red-600)' },
  amber: { bg: 'var(--amber-50)', fg: 'var(--amber-600)' },
  blue: { bg: 'rgba(47,95,219,0.1)', fg: 'var(--blue-600)' },
  muted: { bg: 'var(--bg)', fg: 'var(--muted)' },
};

const STATUS_TONE = {
  'In Use': 'blue',
  'In Stock': 'amber',
  'In Repair': 'red',
  'In Store': 'muted',
  Open: 'blue',
  Hold: 'amber',
  Closed: 'green',
  Present: 'green',
  Absent: 'red',
  Approved: 'green',
  Mismatch: 'red',
  Active: 'green',
  Running: 'green',
  Warning: 'amber',
  'Needs Review': 'red',
  Deprecated: 'muted',
};

export default function StatusBadge({ label, tone }) {
  const t = TONES[tone || STATUS_TONE[label] || 'muted'];
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        padding: '4px 10px',
        borderRadius: 999,
        fontSize: 12.5,
        fontWeight: 600,
        background: t.bg,
        color: t.fg,
        whiteSpace: 'nowrap',
      }}
    >
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: t.fg }} />
      {label}
    </span>
  );
}

// Small colour-coded "N Label" chip — used on the dashboard home cards to show
// a clear breakdown (e.g. "12 Present" / "3 Absent") instead of a description.
export function CountChip({ label, value, tone }) {
  const t = TONES[tone || STATUS_TONE[label] || 'muted'];
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 7,
        padding: '6px 12px',
        borderRadius: 999,
        fontSize: 12.5,
        fontWeight: 700,
        background: t.bg,
        color: t.fg,
        whiteSpace: 'nowrap',
        border: `1px solid ${t.fg}26`,
      }}
    >
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: t.fg, flexShrink: 0 }} />
      <span style={{ fontWeight: 800 }}>{value}</span>
      <span style={{ fontWeight: 600, opacity: 0.85 }}>{label}</span>
    </span>
  );
}
