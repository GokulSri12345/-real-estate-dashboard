export default function Gauge({ value, max, size = 84, stroke = 9, color = 'var(--blue-600)', track = 'var(--border)', centerLabel, centerSub }) {
  const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - pct / 100);

  return (
    <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeDasharray={c}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset .5s ease' }}
        />
      </svg>
      <div
        style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <span style={{ fontFamily: "'Sora',sans-serif", fontWeight: 800, fontSize: size * 0.22, color: 'var(--ink)', lineHeight: 1 }}>
          {centerLabel ?? `${pct}%`}
        </span>
        {centerSub && <span style={{ fontSize: size * 0.11, color: 'var(--muted)', marginTop: 2 }}>{centerSub}</span>}
      </div>
    </div>
  );
}
