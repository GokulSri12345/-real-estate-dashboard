export default function SectionShell({ title, subtitle, actions, children }) {
  return (
    <div style={{ padding: '26px 28px 60px', maxWidth: 1180, margin: '0 auto' }}>
      <div
        style={{
          display: 'flex',
          alignItems: 'flex-start',
          justifyContent: 'space-between',
          gap: 16,
          marginBottom: 22,
          flexWrap: 'wrap',
        }}
      >
        <div>
          <h2 style={{ fontSize: 22, fontWeight: 800 }}>{title}</h2>
          {subtitle && <p style={{ margin: '4px 0 0', color: 'var(--muted)', fontSize: 13.5 }}>{subtitle}</p>}
        </div>
        {actions && <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>{actions}</div>}
      </div>
      {children}
    </div>
  );
}

export function StatPill({ value, label, tone }) {
  return (
    <div
      style={{
        border: '1px solid var(--border)',
        background: 'var(--surface)',
        borderRadius: 12,
        padding: '14px 18px',
        minWidth: 108,
        boxShadow: 'var(--shadow-card)',
      }}
    >
      <div style={{ fontSize: 24, fontWeight: 800, color: tone || 'var(--ink)' }}>{value}</div>
      <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 2 }}>{label}</div>
    </div>
  );
}

export function Table({ columns, rows, renderCell }) {
  return (
    <div
      className="scroll-thin"
      style={{
        border: '1px solid var(--border)',
        borderRadius: 14,
        overflow: 'auto',
        background: 'var(--surface)',
        boxShadow: 'var(--shadow-card)',
      }}
    >
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13.5 }}>
        <thead>
          <tr style={{ background: 'var(--bg)' }}>
            {columns.map((c) => (
              <th
                key={c}
                style={{
                  textAlign: 'left',
                  padding: '11px 16px',
                  fontWeight: 700,
                  color: 'var(--muted)',
                  fontSize: 12,
                  borderBottom: '1px solid var(--border)',
                }}
              >
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i} style={{ borderBottom: i === rows.length - 1 ? 'none' : '1px solid var(--border)' }}>
              {renderCell(row, i)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
