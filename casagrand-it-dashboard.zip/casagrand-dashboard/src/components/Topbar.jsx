import { Moon, Sun, LogOut, ChevronLeft } from 'lucide-react';
import logo from '../assets/casagrand-logo.png';

export default function Topbar({ theme, onToggleTheme, date, onDateChange, user, onLogout, onBack, sectionTitle }) {
  return (
    <header
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '14px 28px',
        background: 'var(--surface)',
        borderBottom: '1px solid var(--border)',
        position: 'sticky',
        top: 0,
        zIndex: 20,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <img src={logo} alt="Casagrand" style={{ height: 34, objectFit: 'contain' }} />
        <div style={{ width: 1, height: 28, background: 'var(--border)' }} />
        {sectionTitle ? (
          <button
            onClick={onBack}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              border: 'none',
              background: 'transparent',
              cursor: 'pointer',
              color: 'var(--navy-800)',
              fontWeight: 700,
              fontSize: 15,
            }}
          >
            <ChevronLeft size={18} /> {sectionTitle}
          </button>
        ) : (
          <div>
            <h1 style={{ fontSize: 17, fontWeight: 700 }}>IT Operations Portal</h1>
            <p style={{ margin: 0, fontSize: 12, color: 'var(--muted)' }}>Casagrand &middot; Enterprise Edition</p>
          </div>
        )}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <input
          type="date"
          value={date}
          onChange={(e) => onDateChange(e.target.value)}
          style={{
            border: '1px solid var(--border)',
            background: 'var(--bg)',
            color: 'var(--ink)',
            borderRadius: 8,
            padding: '7px 10px',
            fontSize: 13,
            fontFamily: 'inherit',
          }}
        />
        <button
          onClick={onToggleTheme}
          title="Toggle theme"
          style={{
            width: 34,
            height: 34,
            borderRadius: 8,
            border: '1px solid var(--border)',
            background: 'var(--bg)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            color: 'var(--ink)',
          }}
        >
          {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
        </button>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div
            style={{
              width: 32,
              height: 32,
              borderRadius: '50%',
              background: 'var(--amber-500)',
              color: '#122238',
              fontWeight: 700,
              fontSize: 13,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {user?.charAt(0)?.toUpperCase() || 'A'}
          </div>
          <div style={{ lineHeight: 1.2 }}>
            <div style={{ fontSize: 13, fontWeight: 600 }}>{user}</div>
            <div style={{ fontSize: 11, color: 'var(--muted)' }}>IT Admin</div>
          </div>
        </div>
        <button
          onClick={onLogout}
          title="Log out"
          style={{
            width: 34,
            height: 34,
            borderRadius: 8,
            border: '1px solid var(--border)',
            background: 'var(--bg)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            color: 'var(--red-600)',
          }}
        >
          <LogOut size={16} />
        </button>
      </div>
    </header>
  );
}
