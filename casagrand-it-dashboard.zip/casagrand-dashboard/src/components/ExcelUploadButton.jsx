import { useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import { UploadCloud } from 'lucide-react';

export default function ExcelUploadButton({ onRows, label = 'Bulk upload (Excel)' }) {
  const inputRef = useRef(null);
  const [busy, setBusy] = useState(false);

  function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const wb = XLSX.read(evt.target.result, { type: 'array' });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet, { defval: '' });
        onRows(rows, file.name);
      } catch {
        alert('Could not read that file. Please upload a valid .xlsx or .csv file.');
      } finally {
        setBusy(false);
        e.target.value = '';
      }
    };
    reader.readAsArrayBuffer(file);
  }

  return (
    <>
      <button
        onClick={() => inputRef.current?.click()}
        disabled={busy}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          border: '1px solid var(--border)',
          background: 'var(--surface)',
          color: 'var(--navy-800)',
          borderRadius: 9,
          padding: '9px 14px',
          fontSize: 13,
          fontWeight: 600,
          cursor: busy ? 'default' : 'pointer',
        }}
      >
        <UploadCloud size={15} />
        {busy ? 'Reading...' : label}
      </button>
      <input ref={inputRef} type="file" accept=".xlsx,.xls,.csv" onChange={handleFile} hidden />
    </>
  );
}
