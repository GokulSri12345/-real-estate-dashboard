export default function ModuleCard({ icon: Icon, title, description, highlight, highlightLabel, accent, disabled, onClick }) {
  return (
    <button
      onClick={disabled ? undefined : onClick}
      className="module-card"
      style={{
        textAlign: 'left',
        border: '1px solid var(--border)',
        background: 'var(--surface)',
        borderRadius: 'var(--radius-md)',
        padding: '20px 20px 18px',
        cursor: disabled ? 'default' : 'pointer',
        boxShadow: 'var(--shadow-card)',
        opacity: disabled ? 0.55 : 1,
        display: 'flex',
        flexDirection: 'column',
        gap: 14,
        minHeight: 160,
        position: 'relative',
        transition: 'transform .15s ease, box-shadow .15s ease',
      }}
      onMouseEnter={(e) => {
        if (disabled) return;
        e.currentTarget.style.animation = 'shake .4s ease';
        e.currentTarget.style.boxShadow = 'var(--shadow-pop)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.animation = 'none';
        e.currentTarget.style.boxShadow = 'var(--shadow-card)';
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div
          style={{
            width: 40,
            height: 40,
            borderRadius: 10,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: accent || 'var(--navy-800)',
            color: '#fff',
          }}
        >
          <Icon size={20} strokeWidth={2} />
        </div>
        {disabled && (
          <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted)' }}>Coming soon</span>
        )}
      </div>

      <div>
        <h3 style={{ fontSize: 16, fontWeight: 700 }}>{title}</h3>
        {description && (
          <p style={{ margin: '4px 0 0', fontSize: 12.5, color: 'var(--muted)', lineHeight: 1.45 }}>{description}</p>
        )}
      </div>

      {highlight !== undefined && (
        <div style={{ marginTop: 'auto', paddingTop: 6, borderTop: '1px solid var(--border)' }}>
          <span style={{ fontFamily: "'Sora',sans-serif", fontSize: 24, fontWeight: 800, color: 'var(--ink)' }}>
            {highlight}
          </span>
          <span style={{ fontSize: 12, color: 'var(--muted)', marginLeft: 8 }}>{highlightLabel}</span>
        </div>
      )}
    </button>
  );
}
