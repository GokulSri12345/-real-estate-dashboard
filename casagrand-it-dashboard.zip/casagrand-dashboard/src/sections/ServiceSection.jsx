import SectionShell, { Table } from '../components/SectionShell';
import StatusBadge from '../components/StatusBadge';

export default function ServiceSection({ services }) {
  return (
    <SectionShell title="Service Details" subtitle="Server uptime and health across core infrastructure">
      <Table
        columns={['Service', 'IP Address', 'Status']}
        rows={services}
        renderCell={(s) => (
          <>
            <td style={td}>{s.name}</td>
            <td style={td}>{s.ip}</td>
            <td style={td}><StatusBadge label={s.status} /></td>
          </>
        )}
      />
    </SectionShell>
  );
}

const td = { padding: '11px 16px' };
