import { useMemo } from 'react';
import SectionShell from '../components/SectionShell';
import StatusBadge from '../components/StatusBadge';
import ExcelUploadButton from '../components/ExcelUploadButton';

const COLUMNS = ['Active', 'Deprecated'];

export default function ApplicationsSection({ applications, setApplications }) {
  function handleBulkRows(rows) {
    const mapped = rows
      .map((r) => {
        const keys = Object.keys(r).reduce((acc, k) => ({ ...acc, [k.toLowerCase().trim()]: r[k] }), {});
        const name = String(keys.name || keys.application || '').trim();
        if (!name) return null;
        return { name, owner: String(keys.owner || '-'), status: keys.status || 'Active' };
      })
      .filter(Boolean);
    if (mapped.length) setApplications([...applications, ...mapped]);
  }

  const grouped = useMemo(
    () => COLUMNS.reduce((acc, c) => ({ ...acc, [c]: applications.filter((a) => a.status === c) }), {}),
    [applications]
  );

  return (
    <SectionShell
      title="Applications"
      subtitle="IT-managed applications and platform ownership"
      actions={<ExcelUploadButton onRows={handleBulkRows} label="Bulk upload applications" />}
    >
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(220px, 1fr))', gap: 16 }}>
        {COLUMNS.map((col) => (
          <div key={col} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 14, padding: 14, boxShadow: 'var(--shadow-card)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <span style={{ fontWeight: 700, fontSize: 13.5 }}>{col}</span>
              <StatusBadge label={col} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {grouped[col].map((a, i) => (
                <div key={i} style={{ border: '1px solid var(--border)', borderRadius: 10, padding: 10, background: 'var(--bg)' }}>
                  <div style={{ fontWeight: 600, fontSize: 13.5 }}>{a.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 2 }}>{a.owner}</div>
                </div>
              ))}
              {grouped[col].length === 0 && <p style={{ fontSize: 12, color: 'var(--muted)' }}>No applications here.</p>}
            </div>
          </div>
        ))}
      </div>
    </SectionShell>
  );
}
