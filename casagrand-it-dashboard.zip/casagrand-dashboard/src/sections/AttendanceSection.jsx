import { useMemo, useRef, useState } from 'react';
import { UploadCloud, CheckCircle2, XCircle } from 'lucide-react';
import SectionShell, { StatPill } from '../components/SectionShell';
import StatusBadge from '../components/StatusBadge';
import { processAttendanceFile } from '../utils/attendanceFile';

export default function AttendanceSection({ employees, date, onActivity, onUploadSummary }) {
  const [uploads, setUploads] = useState([]); // {fileName, kind, rows, note}
  const [busy, setBusy] = useState(false);
  const inputRef = useRef(null);

  const presentCount = useMemo(() => employees.filter((e) => e.status === 'Present').length, [employees]);
  const absentCount = employees.length - presentCount;

  async function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const result = await processAttendanceFile(file);
      setUploads((u) => [result, ...u]);
      if (result.kind === 'parsed') {
        const approved = result.rows.filter((r) => r.verdict === 'Approved').length;
        const mismatch = result.rows.filter((r) => r.verdict === 'Mismatch').length;
        onActivity?.(`uploaded ${result.fileName} \u2014 ${approved} approved, ${mismatch} mismatch`);
        onUploadSummary?.({ fileName: result.fileName, approved, mismatch, time: new Date().toISOString() });
      } else {
        onActivity?.(`uploaded ${result.fileName} for manual review`);
      }
    } catch {
      alert('Could not process this file. Please try again.');
    } finally {
      setBusy(false);
      e.target.value = '';
    }
  }

  return (
    <SectionShell
      title="Attendance"
      subtitle={`Live status for ${new Date(date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}`}
      actions={
        <>
          <button onClick={() => inputRef.current?.click()} disabled={busy} style={primaryBtn}>
            <UploadCloud size={15} /> {busy ? 'Reading...' : 'Upload attendance file'}
          </button>
          <input ref={inputRef} type="file" onChange={handleFile} hidden />
        </>
      }
    >
      <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', marginBottom: 24 }}>
        <StatPill value={employees.length} label="Total employees" />
        <StatPill value={presentCount} label="Present" tone="var(--green-600)" />
        <StatPill value={absentCount} label="Absent" tone="var(--red-600)" />
      </div>

      <h4 style={sectionLabel}>TODAY'S STATUS</h4>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
          gap: 12,
          marginBottom: 30,
        }}
      >
        {employees.map((e) => (
          <div
            key={e.id}
            style={{
              border: `1px solid ${e.status === 'Present' ? 'var(--green-600)' : 'var(--red-600)'}22`,
              borderLeft: `4px solid ${e.status === 'Present' ? 'var(--green-600)' : 'var(--red-600)'}`,
              background: 'var(--surface)',
              borderRadius: 10,
              padding: '12px 14px',
              boxShadow: 'var(--shadow-card)',
            }}
          >
            <div style={{ fontSize: 12, color: 'var(--muted)' }}>{e.id} &middot; {e.dept}</div>
            <div style={{ fontWeight: 700, fontSize: 14, margin: '2px 0 8px' }}>{e.name}</div>
            <StatusBadge label={e.status} />
          </div>
        ))}
      </div>

      <h4 style={sectionLabel}>UPLOADED FILES</h4>
      <p style={{ fontSize: 12.5, color: 'var(--muted)', marginTop: -4, marginBottom: 14 }}>
        Excel or CSV uploads are checked row by row straight from the file — ID, Name and Status must all be
        present and valid, with no duplicate IDs. Every row comes back Approved or Mismatch with a reason.
        PDF, image, or other file formats are accepted and listed, but go to manual review.
      </p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        {uploads.map((up, idx) => (
          <div key={idx} style={{ border: '1px solid var(--border)', borderRadius: 14, background: 'var(--surface)', boxShadow: 'var(--shadow-card)', overflow: 'hidden' }}>
            <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
              <div style={{ fontWeight: 700, fontSize: 13.5 }}>{up.fileName}</div>
              {up.kind === 'parsed' ? (
                <div style={{ display: 'flex', gap: 14, fontSize: 12.5, color: 'var(--muted)' }}>
                  <span><CheckCircle2 size={14} color="var(--green-600)" style={{ verticalAlign: -2 }} /> {up.rows.filter((r) => r.verdict === 'Approved').length} Approved</span>
                  <span><XCircle size={14} color="var(--red-600)" style={{ verticalAlign: -2 }} /> {up.rows.filter((r) => r.verdict === 'Mismatch').length} Mismatch</span>
                </div>
              ) : (
                <StatusBadge label="Manual review" tone="amber" />
              )}
            </div>

            {up.kind === 'parsed' ? (
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead>
                  <tr style={{ background: 'var(--bg)' }}>
                    {['Row', 'Employee ID', 'Name', 'Status', 'Result', 'Reason'].map((c) => (
                      <th key={c} style={{ textAlign: 'left', padding: '9px 14px', fontSize: 11.5, color: 'var(--muted)', fontWeight: 700 }}>{c}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {up.rows.map((r) => (
                    <tr key={r.rowNum} style={{ borderTop: '1px solid var(--border)' }}>
                      <td style={td}>{r.rowNum}</td>
                      <td style={td}>{r.id}</td>
                      <td style={td}>{r.name}</td>
                      <td style={td}>{r.status}</td>
                      <td style={td}><StatusBadge label={r.verdict} /></td>
                      <td style={{ ...td, color: 'var(--muted)' }}>{r.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div style={{ padding: 16, fontSize: 13, color: 'var(--muted)' }}>{up.note}</div>
            )}
          </div>
        ))}
      </div>
    </SectionShell>
  );
}

const sectionLabel = { fontSize: 12.5, color: 'var(--muted)', fontWeight: 700, marginBottom: 12, letterSpacing: 0.2 };
const td = { padding: '9px 14px' };
const primaryBtn = {
  display: 'flex', alignItems: 'center', gap: 6, background: 'var(--blue-600)', color: '#fff',
  border: 'none', borderRadius: 9, padding: '9px 14px', fontSize: 13, fontWeight: 700, cursor: 'pointer',
};
