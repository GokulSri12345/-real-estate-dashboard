import { useMemo } from 'react';
import SectionShell, { StatPill, Table } from '../components/SectionShell';
import StatusBadge from '../components/StatusBadge';
import ExcelUploadButton from '../components/ExcelUploadButton';

export default function EmployeeSection({ employees, setEmployees, infra }) {
  function handleBulkRows(rows) {
    const mapped = rows
      .map((r) => {
        const keys = Object.keys(r).reduce((acc, k) => ({ ...acc, [k.toLowerCase().trim()]: r[k] }), {});
        const id = String(keys.id || keys['employee id'] || '').trim();
        if (!id) return null;
        return {
          id,
          name: String(keys.name || '-'),
          dept: String(keys.dept || keys.department || '-'),
          status: /absent/i.test(keys.status) ? 'Absent' : 'Present',
        };
      })
      .filter(Boolean);
    if (mapped.length) setEmployees([...employees, ...mapped]);
  }

  const byDept = useMemo(() => {
    const map = {};
    employees.forEach((e) => {
      map[e.dept] = map[e.dept] || [];
      map[e.dept].push(e);
    });
    return map;
  }, [employees]);
  const depts = Object.keys(byDept);

  return (
    <SectionShell
      title="Employee Details"
      subtitle="Master employee list & infrastructure allocation"
      actions={<ExcelUploadButton onRows={handleBulkRows} label="Bulk upload employees" />}
    >
      <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', marginBottom: 22 }}>
        <StatPill value={`${infra.allocatedSeats}/${infra.totalSeats}`} label="Seats allocated" />
        <StatPill value={`${infra.activeUsers}/${infra.totalLicenses}`} label="Licenses in use" />
        <StatPill value={employees.length} label="Total employees" />
      </div>

      <h4 style={{ fontSize: 12.5, color: 'var(--muted)', fontWeight: 700, marginBottom: 12 }}>BY DEPARTMENT</h4>
      <div style={{ display: 'grid', gridTemplateColumns: `repeat(${Math.min(depts.length, 4) || 1}, minmax(200px, 1fr))`, gap: 16, marginBottom: 26 }}>
        {depts.map((dept) => (
          <div key={dept} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 14, padding: 14, boxShadow: 'var(--shadow-card)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <span style={{ fontWeight: 700, fontSize: 13.5 }}>{dept}</span>
              <span style={{ fontSize: 11.5, color: 'var(--muted)' }}>{byDept[dept].length}</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {byDept[dept].map((e) => (
                <div key={e.id} style={{ border: '1px solid var(--border)', borderRadius: 10, padding: 10, background: 'var(--bg)' }}>
                  <div style={{ fontWeight: 600, fontSize: 13.5 }}>{e.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--muted)', margin: '2px 0 8px' }}>{e.id}</div>
                  <StatusBadge label={e.status} />
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <h4 style={{ fontSize: 12.5, color: 'var(--muted)', fontWeight: 700, marginBottom: 12 }}>ALL EMPLOYEES</h4>
      <Table
        columns={['Employee ID', 'Name', 'Department', 'Today']}
        rows={employees}
        renderCell={(e) => (
          <>
            <td style={td}>{e.id}</td>
            <td style={td}>{e.name}</td>
            <td style={td}>{e.dept}</td>
            <td style={td}><StatusBadge label={e.status} /></td>
          </>
        )}
      />
    </SectionShell>
  );
}

const td = { padding: '11px 16px' };
