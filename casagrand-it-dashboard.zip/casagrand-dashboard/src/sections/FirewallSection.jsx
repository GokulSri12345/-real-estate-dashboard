import SectionShell, { Table } from '../components/SectionShell';
import StatusBadge from '../components/StatusBadge';

export default function FirewallSection({ firewalls }) {
  return (
    <SectionShell title="Firewall Details" subtitle="Perimeter firewall status and last audit date">
      <Table
        columns={['Firewall', 'Vendor', 'Status', 'Last audit']}
        rows={firewalls}
        renderCell={(f) => (
          <>
            <td style={td}>{f.name}</td>
            <td style={td}>{f.vendor}</td>
            <td style={td}><StatusBadge label={f.status} /></td>
            <td style={td}>{f.lastAudit}</td>
          </>
        )}
      />
    </SectionShell>
  );
}

const td = { padding: '11px 16px' };
