import { useMemo, useState } from 'react';
import { Plus } from 'lucide-react';
import SectionShell from '../components/SectionShell';
import StatusBadge from '../components/StatusBadge';

const COLUMNS = ['Open', 'Hold', 'Closed'];

export default function TicketsSection({ tickets, setTickets, onActivity }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ subject: '', raisedBy: '' });

  const grouped = useMemo(
    () => COLUMNS.reduce((acc, c) => ({ ...acc, [c]: tickets.filter((t) => t.status === c) }), {}),
    [tickets]
  );

  function addTicket(e) {
    e.preventDefault();
    if (!form.subject.trim()) return;
    const id = 'TCK-' + Math.floor(3000 + Math.random() * 900);
    setTickets([{ id, subject: form.subject, raisedBy: form.raisedBy || 'Unassigned', status: 'Open' }, ...tickets]);
    onActivity?.(`opened ticket ${id} \u2014 ${form.subject}`);
    setForm({ subject: '', raisedBy: '' });
    setShowForm(false);
  }

  function moveTicket(id, status) {
    setTickets(tickets.map((t) => (t.id === id ? { ...t, status } : t)));
    onActivity?.(`moved ticket ${id} to ${status}`);
  }

  return (
    <SectionShell
      title="Tickets"
      subtitle="Open · Hold · Closed"
      actions={
        <button onClick={() => setShowForm((s) => !s)} style={primaryBtn}>
          <Plus size={15} /> Open ticket
        </button>
      }
    >
      {showForm && (
        <form onSubmit={addTicket} style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap' }}>
          <input placeholder="Subject" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} style={inp} />
          <input placeholder="Raised by" value={form.raisedBy} onChange={(e) => setForm({ ...form, raisedBy: e.target.value })} style={inp} />
          <button type="submit" style={primaryBtn}>Create</button>
        </form>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(220px, 1fr))', gap: 16 }}>
        {COLUMNS.map((col) => (
          <div key={col} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 14, padding: 14, boxShadow: 'var(--shadow-card)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <span style={{ fontWeight: 700, fontSize: 13.5 }}>{col}</span>
              <StatusBadge label={col} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {grouped[col].map((t) => (
                <div key={t.id} style={{ border: '1px solid var(--border)', borderRadius: 10, padding: 10, background: 'var(--bg)' }}>
                  <div style={{ fontSize: 12, color: 'var(--muted)' }}>{t.id}</div>
                  <div style={{ fontWeight: 600, fontSize: 13.5, margin: '3px 0 6px' }}>{t.subject}</div>
                  <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 8 }}>{t.raisedBy}</div>
                  <select value={t.status} onChange={(e) => moveTicket(t.id, e.target.value)} style={{ ...inp, width: '100%', fontSize: 12 }}>
                    {COLUMNS.map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </div>
              ))}
              {grouped[col].length === 0 && <p style={{ fontSize: 12, color: 'var(--muted)' }}>No tickets here.</p>}
            </div>
          </div>
        ))}
      </div>
    </SectionShell>
  );
}

const inp = { border: '1px solid var(--border)', borderRadius: 8, padding: '9px 10px', fontSize: 13, background: 'var(--bg)', color: 'var(--ink)' };
const primaryBtn = {
  display: 'flex', alignItems: 'center', gap: 6, background: 'var(--blue-600)', color: '#fff',
  border: 'none', borderRadius: 9, padding: '9px 14px', fontSize: 13, fontWeight: 700, cursor: 'pointer',
};
