import { useMemo, useState } from 'react';
import { Plus } from 'lucide-react';
import SectionShell, { StatPill, Table } from '../components/SectionShell';
import StatusBadge from '../components/StatusBadge';
import ExcelUploadButton from '../components/ExcelUploadButton';

const STATUSES = ['In Use', 'In Stock', 'In Repair', 'In Store'];

export default function AssetsSection({ assets, setAssets, onActivity }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ id: '', type: 'Laptop', model: '', assignedTo: '', status: 'In Stock' });

  const counts = useMemo(
    () => STATUSES.map((s) => ({ status: s, n: assets.filter((a) => a.status === s).length })),
    [assets]
  );

  function addAsset(e) {
    e.preventDefault();
    if (!form.id.trim() || !form.model.trim()) return;
    setAssets([...assets, { ...form, assignedTo: form.assignedTo || '-' }]);
    onActivity?.(`added asset ${form.id} (${form.model})`);
    setForm({ id: '', type: 'Laptop', model: '', assignedTo: '', status: 'In Stock' });
    setShowForm(false);
  }

  function handleBulkRows(rows) {
    const mapped = rows
      .map((r) => {
        const keys = Object.keys(r).reduce((acc, k) => ({ ...acc, [k.toLowerCase().trim()]: r[k] }), {});
        const id = String(keys.id || keys['asset id'] || '').trim();
        if (!id) return null;
        return {
          id,
          type: String(keys.type || 'Laptop'),
          model: String(keys.model || '-'),
          assignedTo: String(keys['assigned to'] || keys.assignedto || '-') || '-',
          status: STATUSES.includes(keys.status) ? keys.status : 'In Stock',
        };
      })
      .filter(Boolean);
    if (mapped.length) {
      setAssets([...assets, ...mapped]);
      onActivity?.(`bulk uploaded ${mapped.length} asset record(s)`);
    }
  }

  return (
    <SectionShell
      title="IT Assets"
      subtitle="Laptop & desktop stock across use, stock, repair and store"
      actions={
        <>
          <ExcelUploadButton onRows={handleBulkRows} label="Bulk upload assets" />
          <button onClick={() => setShowForm((s) => !s)} style={primaryBtn}>
            <Plus size={15} /> Add asset
          </button>
        </>
      }
    >
      <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', marginBottom: 22 }}>
        {counts.map((c) => (
          <StatPill key={c.status} value={c.n} label={c.status} tone={toneFor(c.status)} />
        ))}
      </div>

      {showForm && (
        <form onSubmit={addAsset} style={formRow}>
          <input placeholder="Asset ID" value={form.id} onChange={(e) => setForm({ ...form, id: e.target.value })} style={inp} />
          <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} style={inp}>
            <option>Laptop</option>
            <option>Desktop</option>
          </select>
          <input placeholder="Model" value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} style={inp} />
          <input placeholder="Assigned to" value={form.assignedTo} onChange={(e) => setForm({ ...form, assignedTo: e.target.value })} style={inp} />
          <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })} style={inp}>
            {STATUSES.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
          <button type="submit" style={primaryBtn}>Save</button>
        </form>
      )}

      <Table
        columns={['Asset ID', 'Type', 'Model', 'Assigned to', 'Status']}
        rows={assets}
        renderCell={(a) => (
          <>
            <td style={td}>{a.id}</td>
            <td style={td}>{a.type}</td>
            <td style={td}>{a.model}</td>
            <td style={td}>{a.assignedTo}</td>
            <td style={td}><StatusBadge label={a.status} /></td>
          </>
        )}
      />
    </SectionShell>
  );
}

function toneFor(status) {
  return { 'In Use': 'var(--blue-600)', 'In Stock': 'var(--amber-600)', 'In Repair': 'var(--red-600)', 'In Store': 'var(--muted)' }[status];
}

const td = { padding: '11px 16px' };
const inp = { border: '1px solid var(--border)', borderRadius: 8, padding: '9px 10px', fontSize: 13, background: 'var(--bg)', color: 'var(--ink)' };
const formRow = { display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 18, alignItems: 'center' };
const primaryBtn = {
  display: 'flex', alignItems: 'center', gap: 6, background: 'var(--blue-600)', color: '#fff',
  border: 'none', borderRadius: 9, padding: '9px 14px', fontSize: 13, fontWeight: 700, cursor: 'pointer',
};
