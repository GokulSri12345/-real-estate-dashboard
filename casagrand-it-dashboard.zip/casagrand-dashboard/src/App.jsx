import { useEffect, useState } from 'react';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import { loadData, saveData } from './utils/storage';

export default function App() {
  const [user, setUser] = useState(() => loadData('user', null));
  const [theme, setTheme] = useState(() => loadData('theme', 'light'));

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    saveData('theme', theme);
  }, [theme]);

  function handleLogin(username) {
    setUser(username);
    saveData('user', username);
  }
  function handleLogout() {
    setUser(null);
    saveData('user', null);
  }

  if (!user) return <Login onLogin={handleLogin} />;

  return (
    <Dashboard
      user={user}
      theme={theme}
      onToggleTheme={() => setTheme((t) => (t === 'light' ? 'dark' : 'light'))}
      onLogout={handleLogout}
    />
  );
}
