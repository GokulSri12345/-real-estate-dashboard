import * as XLSX from 'xlsx';

const SPREADSHEET_EXT = ['xlsx', 'xls', 'csv'];

function getExt(filename) {
  return (filename.split('.').pop() || '').toLowerCase();
}

/**
 * Reads an uploaded attendance file. For spreadsheet formats (xlsx/xls/csv) it parses
 * the real rows and validates each one purely from the file's own data \u2014 no dependency
 * on any internal/demo employee list, so it works the same for any real file uploaded:
 *   - ID present            -> required
 *   - Name present          -> required
 *   - Status is Present/Absent -> required
 *   - ID not repeated elsewhere in the same file -> required
 * A row passing all four checks is Approved; anything else is Mismatch with the reason.
 * Non-spreadsheet files (pdf, image, doc, etc.) are accepted and listed, but flagged
 * for manual review since they can't be parsed client-side without OCR.
 */
export function processAttendanceFile(file) {
  const ext = getExt(file.name);

  if (!SPREADSHEET_EXT.includes(ext)) {
    return Promise.resolve({
      kind: 'unparsed',
      fileName: file.name,
      rows: [],
      note: 'This file format can\u2019t be validated automatically. Upload an Excel or CSV file to check each row in real time.',
    });
  }

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('File read failed'));
    reader.onload = (e) => {
      try {
        const wb = XLSX.read(e.target.result, { type: 'array' });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json(sheet, { defval: '' });

        const idCounts = new Map();
        json.forEach((r) => {
          const keys = Object.keys(r).reduce((acc, k) => ({ ...acc, [k.toLowerCase().trim()]: r[k] }), {});
          const id = String(keys.id || keys['employee id'] || keys['emp id'] || '').trim().toUpperCase();
          if (id) idCounts.set(id, (idCounts.get(id) || 0) + 1);
        });

        const rows = json.map((r, idx) => {
          const keys = Object.keys(r).reduce((acc, k) => ({ ...acc, [k.toLowerCase().trim()]: r[k] }), {});
          const id = String(keys.id || keys['employee id'] || keys['emp id'] || '').trim();
          const name = String(keys.name || keys['employee name'] || '').trim();
          const status = String(keys.status || keys.attendance || '').trim();
          const normalizedStatus = /present/i.test(status) ? 'Present' : /absent/i.test(status) ? 'Absent' : status;

          let verdict = 'Approved';
          let reason = 'All required fields present and valid';

          if (!id) {
            verdict = 'Mismatch';
            reason = 'Employee ID missing';
          } else if (!name) {
            verdict = 'Mismatch';
            reason = 'Name missing';
          } else if (normalizedStatus !== 'Present' && normalizedStatus !== 'Absent') {
            verdict = 'Mismatch';
            reason = status ? `Unrecognised status "${status}"` : 'Status missing';
          } else if (idCounts.get(id.toUpperCase()) > 1) {
            verdict = 'Mismatch';
            reason = 'Duplicate employee ID in this file';
          }

          return {
            rowNum: idx + 1,
            id: id || '-',
            name: name || '-',
            status: normalizedStatus || '-',
            verdict,
            reason,
          };
        });

        resolve({ kind: 'parsed', fileName: file.name, rows, note: '' });
      } catch (err) {
        reject(err);
      }
    };
    reader.readAsArrayBuffer(file);
  });
}
